
import { GoogleGenAI, Type } from "@google/genai";
import { NoteData } from "../types";
import { NOTE_FREQUENCIES } from "../constants";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const generateSilhouetteImage = async (prompt: string): Promise<string | null> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [{ text: `A flowing, ethereal silhouette of ${prompt} made of translucent chiffon silk fabric. The texture features soft, elegant folds and waves. It must be filled with a rich prismatic gradient of vibrant colors: cyan, deep purple, magenta, and soft orange, exactly like high-end abstract fabric art. The silhouette should be set against a stark, pure white background. Minimalist, high-end design, translucent with glowing inner light, no shadows, no background elements.` }]
      },
      config: {
        imageConfig: {
          aspectRatio: "1:1"
        }
      }
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    return null;
  } catch (error) {
    console.error("Error generating image:", error);
    return null;
  }
};

export const generateRandomMelody = async (prompt: string): Promise<NoteData[]> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Create a simple 16-note melody inspired by "${prompt}" using simplified musical notation (numbers 1-7). 1=Do, 2=Re, 3=Mi, 4=Fa, 5=Sol, 6=La, 7=Ti.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            notes: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  value: { type: Type.STRING, description: "The note number '1' through '7'" },
                  duration: { type: Type.NUMBER, description: "Duration in seconds (e.g. 0.25, 0.5, 1.0)" }
                },
                required: ["value", "duration"]
              }
            }
          },
          required: ["notes"]
        }
      }
    });

    const json = JSON.parse(response.text.trim());
    return json.notes.map((n: any) => ({
      value: n.value,
      frequency: NOTE_FREQUENCIES[n.value] || 261.63,
      duration: n.duration || 0.5
    }));
  } catch (error) {
    console.error("Error generating melody:", error);
    return Array.from({ length: 8 }, (_, i) => ({
      value: String((i % 7) + 1),
      frequency: NOTE_FREQUENCIES[String((i % 7) + 1)],
      duration: 0.5
    }));
  }
};
